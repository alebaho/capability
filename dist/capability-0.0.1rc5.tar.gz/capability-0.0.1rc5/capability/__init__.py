# -*- coding: utf-8 -*-

from capability import capability
from capability import tables

__version__ = '0.0.1rc5'  # Current version
